'use strict';

/**
 * WinSpeed migration runner.
 *
 * Safety properties:
 * - selection and legacy duplicate sequences are governed by migration-policy.json;
 * - UAT/manual SQL is excluded from the normal deployment path;
 * - an applied file is immutable: checksum or batch-count drift stops the run;
 * - ledger read/write failures are fatal rather than treated as an empty ledger;
 * - --plan is read-only and never bootstraps or changes the ledger.
 */
require('dotenv').config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MIGRATIONS_DIR = path.join(__dirname, 'migrations');
const POLICY_PATH = path.join(__dirname, 'migration-policy.json');
const sha256 = value => crypto.createHash('sha256').update(value, 'utf8').digest('hex');
const splitBatches = sql => String(sql).split(/^\s*GO\s*$/im).filter(batch => batch.trim());

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
}

function loadPolicy(file = POLICY_PATH) {
  const policy = readJson(file);
  if (policy.schemaVersion !== 1) throw new Error(`Unsupported migration policy schemaVersion: ${policy.schemaVersion}`);
  if (!Array.isArray(policy.excludedFiles) || !Array.isArray(policy.excludedPatterns)) {
    throw new Error('migration-policy.json must define excludedFiles and excludedPatterns arrays.');
  }
  if (!policy.legacyDuplicateSequences || typeof policy.legacyDuplicateSequences !== 'object') {
    throw new Error('migration-policy.json must define legacyDuplicateSequences.');
  }
  if (policy.checksumPolicy !== 'immutable-after-apply') {
    throw new Error('Only checksumPolicy=immutable-after-apply is supported.');
  }
  return policy;
}

function migrationSequence(fileName) {
  const match = path.basename(fileName).match(/^(\d+)_/);
  return match ? Number(match[1]) : null;
}

function compileExcludedPatterns(policy) {
  return policy.excludedPatterns.map(pattern => {
    try { return new RegExp(pattern, 'i'); }
    catch (error) { throw new Error(`Invalid migration exclusion pattern ${pattern}: ${error.message}`); }
  });
}

function validateMigrationPolicy(fileNames, policy) {
  const files = [...fileNames].filter(file => file.toLowerCase().endsWith('.sql')).sort();
  const fileSet = new Set(files);
  const excludedPatterns = compileExcludedPatterns(policy);
  const errors = [];

  for (const file of policy.excludedFiles) {
    if (!fileSet.has(file)) errors.push(`Configured excluded migration is missing: ${file}`);
  }

  const excludedFiles = files.filter(file => policy.excludedFiles.includes(file) || excludedPatterns.some(pattern => pattern.test(file)));
  const excludedSet = new Set(excludedFiles);
  const activeFiles = files.filter(file => !excludedSet.has(file));
  const activeUnsequenced = activeFiles.filter(file => migrationSequence(file) === null);
  if (activeUnsequenced.length) errors.push(`Active migration filename(s) must start with a numeric sequence: ${activeUnsequenced.join(', ')}`);

  const bySequence = new Map();
  for (const file of files) {
    const sequence = migrationSequence(file);
    if (sequence === null) continue;
    const group = bySequence.get(sequence) || [];
    group.push(file);
    bySequence.set(sequence, group);
  }
  const actualDuplicates = new Map([...bySequence].filter(([, group]) => group.length > 1));
  const expectedDuplicates = new Map(Object.entries(policy.legacyDuplicateSequences).map(([sequence, group]) => [Number(sequence), [...group].sort()]));
  const duplicateSequences = new Set([...actualDuplicates.keys(), ...expectedDuplicates.keys()]);
  for (const sequence of [...duplicateSequences].sort((a, b) => a - b)) {
    const actual = [...(actualDuplicates.get(sequence) || [])].sort();
    const expected = [...(expectedDuplicates.get(sequence) || [])].sort();
    if (actual.join('\n') !== expected.join('\n')) {
      errors.push(`Migration sequence ${sequence} does not match the approved legacy group (actual: ${actual.join(', ') || 'none'}; expected: ${expected.join(', ') || 'none'}).`);
    }
  }

  if (errors.length) throw new Error(`Migration policy validation failed:\n- ${errors.join('\n- ')}`);
  return {
    allFiles: files,
    activeFiles,
    excludedFiles,
    legacyDuplicateSequences: [...actualDuplicates].map(([sequence, group]) => ({ sequence, files: [...group] })),
  };
}

function discoverMigrations(directory = MIGRATIONS_DIR, policy = loadPolicy()) {
  const files = fs.readdirSync(directory, { withFileTypes: true })
    .filter(entry => entry.isFile() && entry.name.toLowerCase().endsWith('.sql'))
    .map(entry => entry.name);
  return validateMigrationPolicy(files, policy);
}

function classifyMigration(applied, checksum, batchCount) {
  if (!applied) return 'PENDING';
  if (String(applied.checksum || '').toLowerCase() !== checksum.toLowerCase()) return 'CHECKSUM_DRIFT';
  if (Number(applied.batchCount) !== Number(batchCount)) return 'BATCHCOUNT_DRIFT';
  return 'UNCHANGED';
}

async function ensureLedger(pool) {
  await pool.request().query(`
    IF SCHEMA_ID('wf') IS NULL EXEC('CREATE SCHEMA wf AUTHORIZATION dbo');
    IF OBJECT_ID('wf.SchemaMigration','U') IS NULL
      CREATE TABLE wf.SchemaMigration (
        FileName NVARCHAR(255) NOT NULL PRIMARY KEY,
        Checksum CHAR(64) NOT NULL,
        BatchCount INT NOT NULL,
        AppliedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        AppliedBy NVARCHAR(128) NULL DEFAULT SUSER_SNAME()
      );
  `);
}

async function loadApplied(pool) {
  const metadata = (await pool.request().query("SELECT OBJECT_ID('wf.SchemaMigration','U') AS LedgerId, HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','VIEW DEFINITION') AS CanInspect")).recordset?.[0];
  if (!metadata) throw new Error('Cannot inspect migration ledger metadata');
  if (metadata.LedgerId == null) {
    if (Number(metadata.CanInspect) !== 1) throw new Error('Cannot prove migration ledger is absent: VIEW DEFINITION required');
    return new Map();
  }
  const result = await pool.request().query('SELECT FileName, Checksum, BatchCount, AppliedAt, AppliedBy FROM wf.SchemaMigration');
  return new Map((result.recordset || []).map(row => [row.FileName, {
    checksum: row.Checksum,
    batchCount: row.BatchCount,
    appliedAt: row.AppliedAt,
    appliedBy: row.AppliedBy,
  }]));
}

/**
 * บันทึกว่า migration ไฟล์นี้ถูกใช้แล้ว
 *
 * ต้องบังคับ USE ก่อนเสมอ เพราะ **migration บางไฟล์มีคำสั่ง `USE` ฝังอยู่ข้างใน**
 * (074_fix_winspeed_legacy_raiserror.sql บรรทัด 53 เขียน `USE dbwins_worldfert9;` ตายตัว)
 * พอรันกับฐานที่ชื่ออื่น — เช่น dbwins_worldfert9_test — session จะสลับไปฐาน production
 * แล้วทุกอย่างหลังจากนั้น รวมทั้งการเขียน ledger บรรทัดนี้ ไปลงผิดฐาน
 *
 * อาการที่เห็นคือ PRIMARY KEY ชนที่ wf.SchemaMigration ทั้งที่ฐานเป้าหมายไม่มีแถวนั้น
 * (ชื่อ constraint ในข้อความ error เป็นของอีกฐานหนึ่ง — เป็นเบาะแสเดียวที่มองเห็น)
 *
 * แก้ที่ตัวรันแทนการแก้ไฟล์ migration เพราะไฟล์ที่ใช้ไปแล้วเป็น immutable
 * การแก้ไฟล์จะทำให้ทุกปลายทางที่ใช้ 074 ไปแล้วเกิด checksum drift พร้อมกัน
 */
/** ชื่อฐานที่ตัวรันกำลังทำงานอยู่ — เก็บไว้ตอนเริ่ม run() ก่อน migration ตัวใดจะสลับฐานได้ */
let targetDatabase = null;

async function resolveTargetDatabase(pool) {
  const r = await pool.request().query('SELECT DB_NAME() AS n');
  targetDatabase = r.recordset[0].n;
  return targetDatabase;
}

async function recordApplied(pool, fileName, checksum, batchCount) {
  if (targetDatabase) {
    await pool.request().query(`USE [${targetDatabase.replace(/]/g, ']]')}];`);
  }
  await pool.request()
    .input('f', fileName)
    .input('c', checksum)
    .input('b', batchCount)
    .query('INSERT INTO wf.SchemaMigration (FileName, Checksum, BatchCount) VALUES (@f, @c, @b);');
}

const IGNORABLE_CODES = [
  1913, // index already exists after a recoverable partial run
  2714, // object already exists after a recoverable partial run
  2705, // column already exists after a recoverable partial run
];

function sqlErrorCode(error) {
  return error?.originalError?.info?.number
    ?? error?.originalError?.number
    ?? error?.number
    ?? error?.originalError?.code;
}

/**
 * migration ต้องไม่สลับฐานเอง — ตัวรันเป็นคนเลือกฐานปลายทางแล้ว
 *
 * `074_fix_winspeed_legacy_raiserror.sql` มี `USE dbwins_worldfert9;` ฝังไว้ตายตัว
 * รันกับฐานชื่ออื่นเมื่อไร คำสั่งที่เหลือทั้งไฟล์จะไปลงฐาน production เงียบ ๆ
 * — ในเคสจริงคือไปแก้ trigger ที่ production ขณะที่ตั้งใจจะทำ UAT
 *
 * หยุดดังดีกว่าเขียนผิดฐานโดยไม่มีใครรู้ ถ้าต้องใช้ไฟล์แบบนี้กับฐานชื่ออื่นจริง ๆ
 * ให้แก้ที่ไฟล์ migration (สร้างไฟล์ใหม่) ไม่ใช่ปล่อยให้ข้ามไป
 */
function assertNoDatabaseSwitch(fileName, batches, database) {
  if (!database) return;
  // ต้องเผื่อคอมเมนต์ท้ายบรรทัด — ของจริงเขียนว่า
  //   USE dbwins_worldfert9;      -- << แก้ชื่อฐานข้อมูลให้ตรงถ้าใช้ที่อื่น
  const re = /^[ \t]*USE\s+\[?([A-Za-z0-9_]+)\]?[ \t]*;?[ \t]*(?:--.*)?$/gim;
  for (const batch of batches) {
    for (const m of batch.matchAll(re)) {
      if (m[1].toLowerCase() !== database.toLowerCase()) {
        throw new Error(
          `${fileName} มีคำสั่ง "USE ${m[1]}" อยู่ข้างใน แต่กำลังรันกับฐาน "${database}" — ` +
          `ถ้าปล่อยไป คำสั่งที่เหลือจะไปลงฐาน ${m[1]} แทน ` +
          `แก้ที่ไฟล์ migration ให้ไม่ต้องสลับฐาน แล้วค่อยรันใหม่`);
      }
    }
  }
}

function executionBatches(fileName, text, database, overrides = {}) {
  const override = overrides[fileName];
  let executable = text;
  if (override) {
    if (sha256(text) !== override.checksum) throw new Error('Database-context override checksum mismatch: ' + fileName);
    executable = text.replace(/^[ \t]*USE\s+\[?([A-Za-z0-9_]+)\]?[ \t]*;?[ \t]*(?:--.*)?$/gim, (line, name) => {
      if (name.toLowerCase() !== override.database.toLowerCase()) throw new Error('Unexpected database directive: ' + name);
      return '-- Database context remains pinned by migration runner.';
    });
  }
  const batches = splitBatches(executable);
  assertNoDatabaseSwitch(fileName, batches, database);
  return batches;
}

async function runFile(pool, fileName, batches) {
  const overrides = loadPolicy().databaseContextOverrides || {};
  if (overrides[fileName]) batches = executionBatches(fileName, fs.readFileSync(path.join(MIGRATIONS_DIR,fileName),'utf8'), targetDatabase, overrides);

  assertNoDatabaseSwitch(fileName, batches, targetDatabase);
  // Local temporary tables require both one connection and SQL batches, not RPC query scope.
  const session = batches.some(text => /\bCREATE\s+TABLE\s+#/i.test(text)) ? pool.transaction() : null;
  if (session) await session.begin();
  let successCount = 0;
  let ignoredCount = 0;
  try {
  for (let index = 0; index < batches.length; index += 1) {
    try {
      if (session) await session.request().batch(batches[index]);
      else await pool.request().query(batches[index]);
      successCount += 1;
    } catch (error) {
      const code = sqlErrorCode(error);
      if (IGNORABLE_CODES.includes(code)) {
        ignoredCount += 1;
        continue;
      }
      const wrapped = new Error(`${fileName} batch ${index + 1}/${batches.length} failed${code ? ` (SQL ${code})` : ''}: ${error.message}`);
      wrapped.cause = error;
      throw wrapped;
    }
  }
  if (session) await session.commit();
  } catch (error) {
    if (session) await session.rollback().catch(() => {});
    throw error;
  }
  return { successCount, ignoredCount, batchCount: batches.length };
}

function buildPlan(inventory, applied, directory = MIGRATIONS_DIR) {
  const entries = inventory.activeFiles.map(file => {
    const sql = fs.readFileSync(path.join(directory, file), 'utf8');
    const checksum = sha256(sql);
    const batches = splitBatches(sql);
    return {
      file,
      batches,
      checksum,
      batchCount: batches.length,
      status: classifyMigration(applied.get(file), checksum, batches.length),
      applied: applied.get(file) || null,
    };
  });
  const diskSet = new Set(inventory.allFiles);
  return {
    entries,
    ledgerOnly: [...applied.keys()].filter(file => !diskSet.has(file)).sort(),
    excludedApplied: inventory.excludedFiles.filter(file => applied.has(file)).sort(),
  };
}

function parseArgs(argv) {
  const options = { plan: false, help: false };
  for (const arg of argv.slice(2)) {
    if (arg === '--plan' || arg === '--verify-only') options.plan = true;
    else if (arg === '--help' || arg === '-h') options.help = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return options;
}

function printPlan(plan, inventory, target, readOnly) {
  const counts = plan.entries.reduce((acc, entry) => {
    acc[entry.status] = (acc[entry.status] || 0) + 1;
    return acc;
  }, {});
  console.log(`\nMigration ${readOnly ? 'read-only plan' : 'preflight'} for ${String(target).toUpperCase()}`);
  console.log(`  active: ${inventory.activeFiles.length}; excluded: ${inventory.excludedFiles.length}`);
  console.log(`  unchanged: ${counts.UNCHANGED || 0}; pending: ${counts.PENDING || 0}; drift: ${(counts.CHECKSUM_DRIFT || 0) + (counts.BATCHCOUNT_DRIFT || 0)}`);
  for (const entry of plan.entries.filter(item => item.status !== 'UNCHANGED')) console.log(`  ${entry.status.padEnd(16)} ${entry.file}`);
  for (const file of plan.excludedApplied) console.log(`  EXCLUDED_APPLIED ${file}`);
  for (const file of plan.ledgerOnly) console.log(`  LEDGER_ONLY      ${file}`);
  return counts;
}

async function run(options = parseArgs(process.argv), customPool = null, customTarget = null) {
  if (options.help) {
    console.log('Usage: node run_migrations.js [--plan|--verify-only]');
    return;
  }

  const policy = loadPolicy();
  const inventory = discoverMigrations(MIGRATIONS_DIR, policy);
  let pool;
  let target;
  if (customPool) {
    pool = customPool;
    target = customTarget || await resolveTargetDatabase(pool);
  } else {
    const db = require('./db');
    await db.ownerReady;
    pool = db.ownerPool;
    target = db.getTarget();
  }

  await resolveTargetDatabase(pool);
  if (!options.plan) await ensureLedger(pool);
  const applied = await loadApplied(pool);
  const plan = buildPlan(inventory, applied);
  const counts = printPlan(plan, inventory, target, options.plan);

  if (plan.ledgerOnly.length) throw new Error(`Applied migration file(s) are missing from disk: ${plan.ledgerOnly.join(', ')}`);
  const drifted = plan.entries.filter(entry => entry.status.endsWith('_DRIFT'));
  if (drifted.length) {
    throw new Error(`Applied migrations are immutable. Create a new migration instead of editing: ${drifted.map(entry => entry.file).join(', ')}`);
  }
  if (options.plan) {
    console.log('  read-only: no schema, data, or ledger changes were made.');
    return { plan, counts, inventory };
  }

  const appliedList = [];
  for (const entry of plan.entries.filter(item => item.status === 'PENDING')) {
    console.log(`\nApplying ${entry.file}`);
    const result = await runFile(pool, entry.file, entry.batches);
    await recordApplied(pool, entry.file, entry.checksum, entry.batchCount);
    console.log(`  ${result.successCount} OK; ${result.ignoredCount} recoverable duplicate(s); ledger recorded`);
    appliedList.push(entry.file);
  }
  console.log(`\nMigration complete: ${counts.UNCHANGED || 0} unchanged; ${counts.PENDING || 0} applied; ${inventory.excludedFiles.length} excluded.`);
  return { plan, counts, inventory, appliedList };
}

if (require.main === module) {
  run()
    .then(() => process.exit(0))
    .catch(error => {
      console.error(`Migration failed: ${error.message}`);
      process.exit(1);
    });
}

module.exports = {
  run,
  ensureLedger,
  recordApplied,
  sha256,
  splitBatches,
  loadPolicy,
  migrationSequence,
  validateMigrationPolicy,
  discoverMigrations,
  classifyMigration,
  buildPlan,
  parseArgs,
  runFile,
  loadApplied,
  executionBatches,
};
